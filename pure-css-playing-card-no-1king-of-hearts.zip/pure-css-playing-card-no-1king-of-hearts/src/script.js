// No images, just CSS

// www.instagram.com/ivorjetski
// twitter.com/ivorjetski
// www.youtube.com/ivorjetski

// This is just one playing card so we are probably going to need 51 others! :O Fork and help! It would be great to see 51 different styles!

// Follow me for CSS only card games