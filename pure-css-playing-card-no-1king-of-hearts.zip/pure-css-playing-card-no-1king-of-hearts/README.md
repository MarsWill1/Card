# Pure CSS Playing Card No.1 - King of Hearts

A Pen created on CodePen.io. Original URL: [https://codepen.io/Marswill1/pen/ZERPGaY](https://codepen.io/Marswill1/pen/ZERPGaY).

The King of Hearts - No images, just CSS.

It was mainly an experiment with  lighting.

Watch a short video of the making of here:
www.youtube.com/ivorjetski
Subscribe for more.

 This is one playing card. We are probably going to need 51 others! :O Fork and help! It would be great to see 51 different styles!

The simpler, the better, for the browsers  sake.

Follow me for CSS only card games...

www.instagram.com/ivorjetski

www.twitter.com/ivorjetski